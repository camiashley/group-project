
while True:
    
    a = int(input("Enter the first number: "))
    b = int(input("Enter the second number: "))
    operator = input("Choose the operation: ")
    
    if operator == '+':
            print('result:', a+b)
    elif operator == '-':
            print('result:', a-b)
    elif operator == '*':
            print('result:', a*b)
    elif operator == '/':
             print('result:', a/b)
    elif operator == '%':
            print('result:', a%b)
    
    else:
        print('the supplied operator:' + operator +' is not a valid operator')
    if input("Repeat the program? (Y/N)").strip().upper() != 'Y':
        break

    

